﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace RodaComponenteCOMPlus
{
    class Program
    {
        static void Main(string[] args)
        {

            MyService.LuckyNumberGenerator gen = new MyService.LuckyNumberGenerator();
            Console.WriteLine("Your lucky number is {0}",gen.GetLuckyNumber());
            gen.ImprimeResultado();

            Console.ReadKey();

        }
    }
}
